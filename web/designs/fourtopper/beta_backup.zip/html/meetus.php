<section class="page-title">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<h2>Meet The Team</h2>
			</div>
		</div>
	</div>
</section>
<section class="main team">
	<div class="style-wrap">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span12">
					<ul class="team-grid">
						<li class="pos1">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-greg.png" /></div></li>
								<li class="title">President</li>
								<li class="name">Greg Brand</li>
								<li class="bio">
									<p>Greg is Bluehouse Group's chief strategist. He's typically the first contact for a new client, and he brings vision and direction to client relationships. His communication skills and ability to quickly switch from right brain to left make him the perfect facilitator for turning client wishes into reality. He's known for creative problem solving and insight, with a touch of diplomacy. He also has learned to surround himself with talented people, and get out of their way when they roll.</p><br>
									<p>While he would happily trade it all in for a life of fly fishing and travel photography, he is an active player in building a healthy business climate in Vermont. As founder and board member of the Vermont Software Developers Alliance, he helped create a statewide trade organization to promote the Vermont creative-tech sector.  He's also been known to cook up fresh-caught salmon for the staff in the office toaster oven.</p>
								</li>
							</ul>
						</li>
						<li class="pos2">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-vicky.png" /></div></li>
								<li class="title">Account &amp; Project Manager</li>
								<li class="name">Vicky Smith</li>
								<li class="bio">
									<p>As the main point of contact for many of our projects, Vicky often gets to know our clients better than any other member of our team, and they in turn get to know her as a receptive problem-solver with a penchant for getting websites to perform better than they’re expected to. She steps into projects armed with her contagious laugh, and an arsenal of high-profile experience that is enough to make you jealous. Before working directly under Vermont ice cream artisans Ben and Jerry, she racked up over fifteen years of television production experience. You'll even find her in the Internet Movie Database for her animation production contributions to MTV networks.</p></br>
									<p>A seasoned city dweller, Vicky spent most of her life living in Manhattan before moving to Vermont. While she still enjoys frequent trips back to the island to visit family and friends, her uniquely New York energy and know-how travel everywhere with her. Vicky is a walking guide to just about everything delicious, fun, and interesting, whether it's here in Vermont, back in New York, or in any one her recent exotic vacation destinations including Senegal, Turkey, and the Galapagos Islands.</p>
								</li>
							</ul>
						</li>
						<li class="pos3">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-josh.png" /></div></li>
								<li class="title">Art Director</li>
								<li class="name">Joshua Turner</li>
								<li class="bio">
									<p>Josh has been working in web/interactive design for over 10 years, which in web terms, is closer to 5,327 years. He helps clients make their web presence both beautiful and usable, and his attention to pixel-perfect detail, intuitive user-interface design and a deep understanding of web standards programming makes him a triple-threat designer. Luckily, he's on our side.</p><br>
									<p>Josh has a BA in Fine Arts with a concentration in graphic design that he earned at Castleton State College. Early in his design career he designed t-shirts for the NFL and MLB (legally) and later worked managing six-figure website redesigns for higher-ed institutions.</p><br>
									<p>When Josh isn't staring at a computer screen, he's cooking with his lovely wife, playing Frisbee with his beagle, manning the counter/mop at Capital Kitchen (his wife's kitchen store in Montpelier), or watching the Boston Red Sox Baseball Club while enjoying a fine pale ale.</p>
								</li>
							</ul>
						</li>
						<li class="pos4">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-chris.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Chris Lewis</li>
								<li class="bio">
									<p>Our philosopher king of PHP Frameworks, heady problems and architectural theory, Chris is the developer deep in code, creating things that are both complex and simple at the same time. A healthy diet of eclectic music and strong coffee fuels his passion for PHP/MySQL/JS, but don't ever try to snooker him at pool.</p><br>
									<p>Once a full-time DJ, Chris is a keen observer of people and the world. He's a hiker, a biker, a snowboarder and a creative writer. He can see a problem from many different sides and bring multiple disciplines to bear on it.</p>
								</li>
							</ul>
						</li>
						<li class="pos5">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-jared.png" /></div></li>
								<li class="title">Developer</li>
								<li class="name">Jared Fullerton</li>
								<li class="bio">
									<p>The pride of Wenatchee, WA, Jared is constantly stalking the perfect user interface design. With his encyclopedic knowledge of standards and obsession with accessibility, he strives to enhance the user experience in everything he does. If you've ever wondered exactly what a degree in electronic media, art and communications from RPI looks like in action, Jared can show you. A consummate problem-solver, he makes it possible to use the word elegant when describing html/css and javascript.</p><br>
									<p>His work is informed by avid consumption of media and pop culture and an undying appetite for what's next in technology and the Web. Despite the ordeal of being the guy who mowed the golf course at one point in his career, he still does manage to get himself outside to cross country ski—which is what we do here in Vermont.</p>
								</li>
							</ul>
						</li>
						<li class="pos6">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/andrewrousseau2.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Andrew Rousseau</li>
								<li class="bio">
									<p>Andrew is a web programmer known for developing highly scalable and robust industry level web applications.  In addition to his programming skills Andrew is a classical guitar educator and director of the Vermont Guitar Ensemble.  When not working he spends his time at home in the Champlain Islands with his wife and four children homeschooling, raising chickens, and cutting wood for the winter.</p>
								</li>
							</ul>
						</li>
						<li class="pos7">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/jim.png" /></div></li>
								<li class="title">Product Manager</li>
								<li class="name">Jim Tourville</li>
								<li class="bio">
									<p>Jim is a Product Manager for Bluehouse Group. In his career, Jim has been a web developer, mentor, soldier, client fulfillment manager and most recently COO, where he spent most of his time arm wrestling the CEO and catering to the beautiful web aspirations of accountants. Jim is also obsessed with Google, RSS feeds, e-readers, organizational orienteering and process improvement.</p>
								</li>
							</ul>
						</li>
						<li class="pos8">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/michael2.png" /></div></li>
								<li class="title">Marketing Manager</li>
								<li class="name">Michael Adams</li>
								<li class="bio">
									<p>Michael loves sales &amp; marketing - so much so he tried to sell a Ron Popeil Showtime Rotisserie to his Dad when he was just seven years old - he failed miserably.</p><br>
									<p>To get some marketing chops, Michael attended Bryant University in Smithfield, RI. Now you can find him knee-deep in Google Analytics and AdWords reports or selling mustard on the weekends (he owns Green Mountain Mustard and keeps the office fridge stocked at all times). Michael loves product strategy, copywriting, and branding brainstorms.</p><br>
									<p>For super-fun times, Michael enjoys working out, photography, and cooking. And he’ll never pass up a chance to go to a flea-market, garage sale, or salvage yard. He owns a collection of vintage maple syrup tins, a one-way street sign, and three Vermont license plates from the 1950's.</p>
								</li>
							</ul>
						</li>
						<li class="pos9">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/samdavis2.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Sam Davis</li>
								<li class="bio">
									<p>A slight boy of gratuitous vocabulary and ravenous hunger, Samuel Davis describes his work as, "Pure juice," "Like a swan," or simply cackles with a mad delight. He is most notable for constantly assuring you that you are his boon companion and your ears are wonderfully symmetrical. Never happier than when wading hip-deep in the nuts-and-bolts of web construction, Sam is better at making a working machine than a pretty one. As a result he's extra cuddly towards the design team. There's nothing quite like building something from nothing; something that does exactly what you want it to do, quickly, quietly, and with a flair of elegance.</p>
								</li>
							</ul>
						</li>
						<li class="pos10">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/zach.png" /></div></li>
								<li class="title">Developer</li>
								<li class="name">Zach Lincoln</li>
								<li class="bio">
									<p>Zach graduated from the University of Vermont in 2011 where he studied marketing, and helped friends start their own businesses.  Always passionate about the web, he has used this experience in conjunction with development here at Bluehouse Group to provide a seamless and enjoyable experience to clients and users alike.</p>
								</li>
							</ul>
						</li>
						<li class="pos11">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/scottmacewan2.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Scott MacEwan</li>
								<li class="bio">
									<p>Scott is a Programming Intern for the Spring 2013 semester. His main project is working on QuizPoo, a this-or-that quiz application developed by Bluehouse Group.</p><br>
									<p>Scott was born and raised in New Hampshire and came to Vermont to attend the University of Vermont. He plans on never leaving (Vermont tends to do that to people). In May, Scott will graduate with a BS in computer science and a BA in mathematics. When he's not coding, Scott likes to ski, hike, camp, and play video games.</p>
								</li>
							</ul>
						</li>
						<li class="pos12">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/andrewpapin2.png" /></div></li>
								<li class="title">Development Intern</li>
								<li class="name">Andrew Papin</li>
								<li class="bio">
									<p>Andrew is the master of small projects at Bluehouse Group. He uses his love for design, development, and the web to help the team with anything they may need. While he was once on his way to becoming a chef, he changed paths when he realized making the Internet beautiful with websites outweighed cooking professionally. Or, maybe he changed paths when he realized he was born on the exact date as the first website. No matter the reason, he's glad he made the change because he can use what he learns at Bluehouse to grow his knowlege of the web and be a part of making the Internet a more beautiful place. In his free time you may find him searching his pocket change for rare coins, or catching up on the latest television shows.</p>
								</li>
							</ul>
						</li>
					</ul>
					<div class="custom-design-callout">
						<h3>Want a Custom Design?</h3>
						<a href="#" class="btn green">Contact Us</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>