<!DOCTYPE html>
<html>
<head>
	<title><?php echo $settings['page_title']; ?></title>
	<meta name="title" content="<?php echo $settings['meta_title']; ?>">
	<meta name="keywords" content="<?php echo $settings['meta_keywords']; ?>">
  <meta name="description" content="<?php echo $settings['meta_description']; ?>">
  <meta name="viewport" content="initial-scale=1.0,width=device-width" />
	<link type="text/css" rel="stylesheet" href="/designs/fourtopper/css/styles.css" />
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="/designs/fourtopper/js/modernizr.custom.37447.js"></script>
	<script type="text/javascript" src="/designs/fourtopper/js/jquery.fittext.js"></script>
	<script type="text/javascript" src="/designs/fourtopper/js/bootstrap.js"></script>
	<script type="text/javascript" src="/designs/fourtopper/js/behavior.js"></script>
	<script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script>
	<script type="text/javascript">
		$(function(){
			//responsive headlines
			$("div.footer-center a.email").fitText(1.4, {minFontSize: '12px', maxFontSize: '16px'});
		});
	</script>
</head>
<body>
<div class="page-container"><!-- for bootstrap modal patch -->
<header>
	<div class="navbar navbar-static-top">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="brand" href="/"><span><img src="/designs/fourtopper/img/logo-main.png" alt="Four Topper" /></span></a>
				<ul class="nav social">
					<li><a href="https://twitter.com/fourtopper" target="_blank" title="Follow Four Topper on Twitter!"><i class="icon icon-twitter"></i></a></li>
					<li><a href="https://www.facebook.com/pages/Fourtopper/176391962498819" target="_blank" title="Find Four Topper on Facebook"><i class="icon icon-facebook-sign"></i></a></li>
				</ul>
				<ul class="nav blog">
					<!-- Zach -> nvm - just hard code them -->
					<?php /* foreach($nav_items as $pos => $nav): ?>
						<?php if($pos < 8 && $pos > 1): ?>
		                	<li><a href="<?php echo $base_path; ?>/<?php echo $nav->getSlug(); ?>"><?php echo $nav->getLabel(); ?></a></li>
		                <?php endif; ?>
	                <?php endforeach;  */ ?>
					<li><a href="/blog">Blog</a></li>
				</ul>
			</div>
		</div>
	</div>
</header>