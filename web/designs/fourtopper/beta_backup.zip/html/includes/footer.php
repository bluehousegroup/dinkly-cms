<div id="signup-success-modal" class="modal hide fade" data-replace="true" tab-index="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="inner-wrap">
		<div class="modal-header clearfix">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">Close x</button>
		</div>
		<div class="modal-body">
			<h3>Sweet! Your restaurant&apos;s website is free for an entire year.</h3>
			<p>That means your online marketing is on us for 365 days!</p>
			<p>A member of our Vermont-based team will be in touch later today or the very next business day to get you started with your site.</p>
			<h4>Not a big fan of waiting? Give us a ring right now at (802) 448-2493.</h4>
			<p>We might be busy baking brownies to celebrate your free website, but we&apos;ll try our best to pick up the phone with our batter-covered hands.</p>

			<p class="pull-left" style="clear:both">Chat soon,</p>
			<p class="pull-left" style="clear:both"><i>The Fourtopper team</i></p>

		</div>
	</div>
</div>

<footer class="">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span5 footer-right offset5">
				<div class="inner-wrap">
					<h3 class="flourish">Start Building My Site</h3>
					<form class="form-horizontal" id="footer-form">
						<div class="control-group">
							<label class="control-label" for="footer-name">Name:</label>
							<div class="controls">
								<input type="text" class="text" id="footer-name" placeholder="Your Name">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="footer-email">Email:</label>
							<div class="controls">
								<input type="email" class="text" id="footer-email" placeholder="something@example.com">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="footer-tel">Phone:</label>
							<div class="controls">
								<input type="tel" class="text" id="footer-tel" placeholder="(555) 555-5555">
							</div>
						</div>
						<div class="control-group">
							<div class="controls action">
								<button type="submit" class="btn yellow freeSite">Start Building My Site!</button>
							</div>
						</div>
					</form>
				</div>
			</div>
			<div class="span3 footer-center pull8">
				<div class="inner-wrap clearfix">
					<h3 class="flourish">Get Support</h3>
					<a href="tel:8024482493" class="tel">(802) 448-2493</a>
					<a href="mailto:help@fourtopper.com" class="email">help@fourtopper.com</a>
				</div>
			</div>
		</div>
	</div>
</footer>
</div><!-- /.page-container -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-1071988-49']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<script>
function submitSignup(customer_name, customer_email, customer_tel) {
	$.post("/api/api/signupsubmit", { name: customer_name, email: customer_email, phone: customer_tel }, function(msg) {
		$("#signup-success-modal").modal({show:true});
	});
}
$(document).ready(function() {
  
	$("body").on("click", ".freeSite", function(e){
		e.preventDefault();
		if($("#footer-email").val() == "") alert("Email is required");
		else submitSignup($("#footer-name").val(), $("#footer-email").val(), $("#footer-tel").val());
		_gaq.push(['_trackEvent', 'Signup', 'Beta', 'Footer', false]);
	});

	$("body").on("click", ".freeSiteModal", function(e){
		e.preventDefault();
		if($("#m-email").val() == "") alert("Email is required");
		else submitSignup($("#m-name").val(), $("#m-email").val(), $("#m-tel").val());
		_gaq.push(['_trackEvent', 'Signup', 'Beta', 'Top Button', false]);
	});

});
</script>

</body>
</html>