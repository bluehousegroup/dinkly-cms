<section class="page-title">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<h2>Designs</h2>
			</div>
		</div>
	</div>
</section>
<section class="main available-themes">
	<div class="style-wrap">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span12">
					<div class="design-intro">
						<h3>Your establishment will never look better online</h3>
						<h4>Hand-crafted original designs for every and any type of restaurant</h4>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<ul class="theme-grid">
						<li class="first-in-row">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li>
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li>
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li class="first-in-row">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li>
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li>
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="custom-design-callout">
						<h3>Want a Custom Design?</h3>
						<a href="#" class="btn green">Contact Us</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>