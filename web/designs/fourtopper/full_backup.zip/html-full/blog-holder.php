<?php include('includes/header.php'); ?>
<section class="page-title">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<h2>Blog</h2>
			</div>
		</div>
	</div>
</section>
<section class="main available-themes">
	<div class="style-wrap">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span12">
					
				</div>
			</div>
		</div>
	</div>
</section>
<?php include('includes/footer.php'); ?>