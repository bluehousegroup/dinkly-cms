<?php include('includes/header.php'); ?>
<!-- beta banner -->
<section class="banner home">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="inner-wrap">
					<h1>Fully-Loaded Restaurant Websites</h1>
					<h2>Wow Your Customers</h2>
					<h3>Let Us Take Care of Your Website</h3>
					<a href="tour.php" class="btn blue">Take the Tour</a>
					<!-- <a href="#video-modal" data-toggle="modal" role="button" class="video-callout"><span class="top">See how it works</span><span class="bottom">Watch the Video</span></a> -->
				</div>
			</div>
		</div>
	</div>
</section>
<section class="testimonial home">
	<section class="features home">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span3 home-left hidden-phone">
					<div class="inner-wrap">
						<h3>Features Up the Wazoo!</h3>
						<ul class="feature-list no-bullets">
							<li>Stunning designs to enhance your image</li>
							<li>Easily update your menu in seconds</li>
							<li>Your website is viewable on any device</li>
							<li>Social media integration to engage customers</li>
							<li>Help when you need changes done quickly</li>
						</ul>
					</div>
				</div>
				<div class="span6 home-center">
					<div class="inner-wrap">
						<ul class="value-components no-bullets">
							<li class="connect clearfix">
								<img src="img/connect-icon.png" alt="connect!" />
								<p><span class="important">Connect.</span> Get the word out about your latest specials and events with ease.  Use social media tools and email marketing to connect with customers.</p>
							</li>
							<li class="control clearfix phone-flipped">
								<img src="img/control-icon.png" alt="control!" />
								<p><span class="important">Control.</span> You're in the driver's seat.  Make changes yourself or take advantage of dedicated support whenever you need it.  You're never left in the dark.</p>
							</li>
							<li class="cash-in clearfix">
								<img src="img/cash-in-icon.png" alt="cash-in!" />
								<p><span class="important">Cash-In.</span> Use online tools to get more customers through your door.  That means more butts in seats - every night.</p>
							</li>
						</ul>
					</div>
				</div>
				<div class="span3 home-right hidden-phone">
					<div class="inner-wrap">
						<img src="img/guarantee.png" alt="Blown Away, Every Day. Guaranteed!" />
						<p><b>You've got 30 days to explore Four Topper.</b><br/><br/>After 30 days, if you're not blown away every day by your experience with Four Topper, you owe us nothing. Nada.  Zero. <a href="#beta-signup-modal" role="button" data-toggle="modal" class="try-link">Try It Out</a></p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<div class="testimonial-wrap">
					<img class="chef-image" src="img/chef.png" alt="chef" />
					<blockquote class="yellow clearfix">
						<img class="blockquote-arrow" src="img/blockquote-yellow.png" />
						<div class="blockquote-inner-wrap">
							<div class="text-wrap">
								<q>Lorem Ipsum is simply dummy text of the printing and typesetting industry.  Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</q>
								<cite>Chef Luiz Guzman, Guzman's Goosefat</cite>
							</div>
						</div>
					</blockquote>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Whats the catch? modal -->
<div id="catch-modal" class="modal hide fade" data-replace="true" tab-index="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="inner-wrap">
		<div class="modal-header clearfix">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">Close x</button>
		</div>
		<div class="modal-body">
			<h3>What's Going On Here?</h3>
			<p>We're looking for our first few users to provide feedback on our product. In exchange, you get your site free for the first year. After that, stay	on-board with Fourtopper at a low monthly rate.</p>
			<p><strong>Bottom line:</strong> You get a free website for a year. Is there anything better
			than free marketing to bring your restaurant more customers?</p>
			<a href="#beta-signup-modal" role="button" data-toggle="modal" class="btn green">Get My Free Site!</a>
		</div>
	</div>
</div>
<div id="video-modal" class="modal hide fade" data-replace="true" tab-index="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h3>Start Your 30 Day free trial today!</h3>
	</div>
	<div class="modal-body">
		<p>placeholder</p>
	</div>
	<div class="modal-footer">
		<button href="#beta-signup-modal" role="button" data-toggle="modal" type="submit" class="btn green">Start Building my Site!</button>
	</div>
</div>
<?php include('includes/footer.php'); ?>