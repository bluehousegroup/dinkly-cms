Refer to:
https://sites.google.com/a/bluehousegroup.com/wiki/guides/sublime-settings/less-compilation

For compiling imported template less files