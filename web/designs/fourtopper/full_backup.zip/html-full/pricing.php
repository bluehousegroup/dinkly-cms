<?php include('includes/header.php'); ?>
<section class="page-title">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<h2>Pricing</h2>
			</div>
		</div>
	</div>
</section>
<section class="main pricing">
	<div class="style-wrap">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span10 offset1">
					<div class="inner-wrap">
						<h2>Try Fourtopper Free For 30 Days</h2>
						<h3>No crazy setup fees, hidden costs, or silly contracts</h3>
						<table class="what-you-get table table-bordered table-striped">
							<thead>
								<tr>
									<th>What You Get</th>
									<th>Fourtopper</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Three Stunning Designs</td>
									<td><i class="checkmark"></i></td>
								</tr>
								<tr>
									<td>Easily Update Your Menu</td>
									<td><i class="checkmark"></i></td>
								</tr>
								<tr>
									<td>Integrate Your Social Media Links</td>
									<td><i class="checkmark"></i></td>
								</tr>
								<tr>
									<td>Add Unlimited Employees</td>
									<td><i class="checkmark"></i></td>
								</tr>
								<tr>
									<td>Dedicated Client Success Manager</td>
									<td><i class="checkmark"></i></td>
								</tr>
								<tr>
									<td>If you're not blown away evert day by your experience with Fourtopper, you owe us nothing. Nada.  Zero. </td>
									<td>
										<span class="price">$49/mo</span>
										<a href="#" class="btn green">Start Building My Site</a>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span5 offset1 block">
					<div class="inner-wrap">
						<h3>What's the deal with the 30-day trial?</h3>
						<p>Try out Fourtopper - fully-loaded - for 30 days.  That includes phone and email support to make sure you're restaurant is represented well on the web.  We don't want to leave you hanging</p>
					</div>
				</div>
				<div class="span5 block">
					<div class="inner-wrap">
						<h3>What if Fourtopper isn't for me?</h3>
						<p>That's crazy talk!  You'll enjoy your Fourtopper experience - we're 103% certain.  If not, walk away and you won't owe us anything - not even a free appetizer.</p>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span5 offset1 block">
					<div class="inner-wrap">
						<h3>Where's the fine print?</h3>
						<p>There isn't any.  It's too small and you probably don't like to squint.  We're just honest people doing what we think is right.  No crazy setup fees, hidden costs, or silly contracts.</p>
					</div>
				</div>
				<div class="span5 block">
					<div class="inner-wrap">
						<h3>What if I don't have time to get my site up?</h3>
						<p>That's what our team of dedicated success managers is for.  Send us your menu and we'll upload it for you at no extra cost.  Because that's how we roll at Fourtopper.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row-fluid testimonial">
			<div class="span12">
				<div class="testimonial-wrap">
					<img class="chef-image" src="img/chef.png" alt="chef" />
					<blockquote class="yellow clearfix">
						<img class="blockquote-arrow" src="img/blockquote-yellow.png" />
						<div class="blockquote-inner-wrap">
							<div class="text-wrap">
								<q>Lorem Ipsum is simply dummy text of the printing and typesetting industry.  Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</q>
								<cite>Chef Luiz Guzman, Guzman's Goosefat</cite>
								<a href="#" class="btn green big">Start Building My Site</a>
								<span class="quick">Takes less than 10 minutes to get started!</span>
							</div>
						</div>
					</blockquote>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include('includes/footer.php'); ?>