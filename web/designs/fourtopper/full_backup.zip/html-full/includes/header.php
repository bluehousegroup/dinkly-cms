<!DOCTYPE html>
<html>
<head>
	<title>Fourtopper Marketing</title>
	<meta name="viewport" content="initial-scale=1.0,width=device-width" />
	<link type="text/css" rel="stylesheet" href="css/styles.css" />
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	<script type="text/javascript" src="javascript/modernizr.custom.37447.js"></script>
	<script type="text/javascript" src="javascript/jquery.fittext.js"></script>
	<script type="text/javascript" src="javascript/bootstrap.js"></script>
	<script type="text/javascript" src="javascript/behavior.js"></script>
	<script type="text/javascript" async="" src="http://www.google-analytics.com/ga.js"></script>
	<script type="text/javascript">
		$(function(){
			//responsive headlines

			$("div.footer-center a.email").fitText(1.4, {minFontSize: '12px', maxFontSize: '16px'});
		});
	</script>
</head>
<body>
<div class="page-container">
<header>
	<div class="navbar navbar-static-top">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand" href="home.php"><span><img src="img/logo-main.png" alt="Four Topper" /></span></a>
				<div class="nav-collapse collapse clearfix">
					<ul class="nav main-nav">
						<li><a href="tour.php">Tour</a></li>
						<li><a href="pricing.php">Pricing</a></li>
						<li><a href="designs.php">Designs</a></li>
					</ul>
					<ul class="nav utility-nav">
						<li><a href="meetus.php">Meet Us</a></li>
						<li class="get-started"><a href="#beta-signup-modal" role="button" data-toggle="modal">Get Started</a></li>
						<li class="social"><a href="#" title="Find Four Topper of Facebook!"><i class="icon icon-facebook-sign"></i><span class="menu-text">Facebook</span></a></li>
						<li class="social"><a href="#" title="Follow Four Topper on Twitter!"><i class="icon icon-twitter"></i><span class="menu-text">Twitter</span></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</header>