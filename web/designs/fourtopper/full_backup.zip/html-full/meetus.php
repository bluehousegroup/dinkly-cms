<?php include('includes/header.php'); ?>
<section class="page-title">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<h2>Meet The Team</h2>
			</div>
		</div>
	</div>
</section>
<section class="main team">
	<div class="style-wrap">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span12">
					<ul class="team-grid">
						<li class="pos1">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-greg.png" /></div></li>
								<li class="title">President</li>
								<li class="name">Greg Brand</li>
								<li class="bio">
									<p>Greg is Bluehouse Group's chief strategist. He's typically the first contact for a new client, and he brings vision and direction to client relationships. His communication skills and ability to quickly switch.</p>
								</li>
							</ul>
						</li>
						<li class="pos2">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-vicky.png" /></div></li>
								<li class="title">Account &amp; Project Manager</li>
								<li class="name">Vicky Smith</li>
								<li class="bio">
									<p>As the main point of contact for many of our projects, Vicky often gets to know our clients better than any other member of our team, and they in turn get to know her as a receptive problem-solve</p>
								</li>
							</ul>
						</li>
						<li class="pos3">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-josh.png" /></div></li>
								<li class="title">Art Director</li>
								<li class="name">Joshua Turner</li>
								<li class="bio">
									<p>Josh has been working in web/interactive design for over 10 years, which in web terms, is closer to 5,327 years. He helps clients make their web presence both beautiful and usable, and his attention to pixel-perfect detail</p>
								</li>
							</ul>
						</li>
						<li class="pos4">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-chris.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Chris Lewis</li>
								<li class="bio">
									<p>Our philosopher king of PHP Frameworks, heady problems and architectural theory, Chris is the developer deep in code, creating things that are both complex and simple at the same time. A healthy diet </p>
								</li>
							</ul>
						</li>
						<li class="pos5">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/bio-jared.png" /></div></li>
								<li class="title">Developer</li>
								<li class="name">Jared Fullerton</li>
								<li class="bio">
									<p>The pride of Wenatchee, WA, Jared is constantly stalking the perfect user interface design. With his encyclopedic knowledge of standards and obsession with accessibility, he strives to enhance the user experience in everything </p>
								</li>
							</ul>
						</li>
						<li class="pos6">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/andrewrousseau2.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Andrew Rousseau</li>
								<li class="bio">
									<p>Andrew is a web programmer known for developing highly scalable and robust industry level web applications.  In addition to his programming skills Andrew is a classical guitar educator and director of the Vermont Guitar E</p>
								</li>
							</ul>
						</li>
						<li class="pos7">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/jim.png" /></div></li>
								<li class="title">Product Manager</li>
								<li class="name">Jim Tourville</li>
								<li class="bio">
									<p>Jim is a Product Manager for Bluehouse Group. In his career, Jim has been a web developer, mentor, soldier, client fulfillment manager and most recently COO, where he spent most of his time arm wrestling the CEO and catering to the beautiful web aspirations of accountants. Jim is also </p>
								</li>
							</ul>
						</li>
						<li class="pos8">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/michael2.png" /></div></li>
								<li class="title">Marketing Manager</li>
								<li class="name">Michael Adams</li>
								<li class="bio">
									<p>Michael loves sales &amp; marketing - so much so he tried to sell a Ron Popeil Showtime Rotisserie to his Dad when he was just seven years old - he failed miserably.</p>
								</li>
							</ul>
						</li>
						<li class="pos9">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/samdavis2.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Sam Davis</li>
								<li class="bio">
									<p>A slight boy of gratuitous vocabulary and ravenous hunger, Samuel Davis describes his work as, "Pure juice," "Like a swan," or simply cackles with a mad delight. He is most notable for constantly assuring you that you are his boon companion and your ears are wonderfully symmetrical. Never </p>
								</li>
							</ul>
						</li>
						<li class="pos10">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/zach.png" /></div></li>
								<li class="title">Developer</li>
								<li class="name">Zach Lincoln</li>
								<li class="bio">
									<p>Zach graduated from the University of Vermont in 2011 where he studied marketing, and helped friends start their own businesses.  Always passionate about the web, he has used this experience in conjunction with development here at Bluehouse Group to provide a seamless and enjoyable experience to clients and users alike.</p>
								</li>
							</ul>
						</li>
						<li class="pos11">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/scottmacewan2.png" /></div></li>
								<li class="title">Programmer</li>
								<li class="name">Scott MacEwan</li>
								<li class="bio">
									<p>Scott is a Programming Intern for the Spring 2013 semester. His main project is working on QuizPoo, a this-or-that quiz application developed by Bluehouse Group.</p>
								</li>
							</ul>
						</li>
						<li class="pos12">
							<ul class="member">
								<li class="photo"><div class="image-wrapper"><img class="photo" src="img/staff/resampled/andrewpapin2.png" /></div></li>
								<li class="title">Development Intern</li>
								<li class="name">Andrew Papin</li>
								<li class="bio">
									<p>Andrew is the master of small projects at Bluehouse Group. He uses his love for design, development, and the web to help the team with anything they may need. While he was once on his way to becoming a chef, </p>
								</li>
							</ul>
						</li>
					</ul>
					<div class="custom-design-callout">
						<h3>Want a Custom Design?</h3>
						<a href="#" class="btn green">Contact Us</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include('includes/footer.php'); ?>