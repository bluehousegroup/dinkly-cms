<?php include('includes/header.php'); ?>
<section class="page-title">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<h2>Designs</h2>
			</div>
		</div>
	</div>
</section>
<section class="main available-themes">
	<div class="style-wrap">
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span12">
					<div class="design-intro">
						<h3>Your establishment will never look better online</h3>
						<h4>Hand-crafted original designs for every type of restaurant</h4>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span10 offset1">
					<ul class="theme-grid">
						<li class="pos1">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li class="pos2">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li class="pos3">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li class="pos4">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li class="pos5">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
						<li class="pos6">
							<img src="http://placehold.it/800x800" alt="design" />
							<div class="mask">
								<a href="#" class="btn yellow get-started">Get Started with this theme</a>
								<a href="#" class="demo-link">See a live demo</a>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="custom-design-callout">
						<h3>Want a Custom Design?</h3>
						<a href="#" class="btn green">Contact Us</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include('includes/footer.php'); ?>